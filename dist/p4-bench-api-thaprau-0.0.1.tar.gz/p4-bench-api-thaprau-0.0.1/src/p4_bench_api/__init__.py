from p4_bench_api.model import Node, Switch, Link, NetworkSetup
from p4_bench_api.p4_api import *
